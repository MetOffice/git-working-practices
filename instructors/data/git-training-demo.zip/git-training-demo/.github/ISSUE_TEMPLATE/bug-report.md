---
name: Bug Report
about: Submit a bug report.
title: ''
labels: bug
assignees: ''

---

## Summary

<!--
Please add a summary of the bug.
-->

## How to Reproduce

<!--
Outline steps to reproduce the bug.
-->

## Expected Behaviour

<!--
State the expected behaviour.
-->

## Environment

 - Computing Platform [e.g., ARCHER2]
 - Compiler Version & Options [e.g., Cray]

## Potential Fix

<!--
Outline a potential fix.
-->

## Additional context

<!-- Provide any further information -->
<details>
<summary>Click to expand <b>this section...</b></summary>

```
Please add additional verbose information in this section e.g., code, output, tracebacks, screenshots etc
```
</details>
