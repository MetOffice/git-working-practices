# git-training-demo

For use during the git and GitHub training.
